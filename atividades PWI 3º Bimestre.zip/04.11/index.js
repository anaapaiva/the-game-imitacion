let arquivoImagens = ["1.png", "2.png", "3.png", "4.png"]; //Índice começa em zero
let contador = 0;

let a = `Hashira `;
let b = `  Inosuke Hashibira `;
let c = `               xy           `;
let d = `           combate               `;
let texto = [a, b, c, d];


function atualizarImagem() {
  let img = document.querySelector("#foto");
  img.src = arquivoImagens[contador];
  let eletexto = document.querySelector("#texto");
  eletexto.innerText = texto[contador];
}

function proximaImagem() {
  contador++;
  if (contador === 4) {
    contador = 0;
  }
  atualizarImagem();
}
function imagemAnterior() {
  contador--;
  if (contador === -1) {
    contador = 3;
  }
  atualizarImagem();
}

let btnEsquerda = document.querySelector("#esquerda");
btnEsquerda.addEventListener("click", imagemAnterior);

let btnDireita = document.querySelector("#direita");
btnDireita.addEventListener("click", proximaImagem);



function GerenciarTeclado(evento) {
  switch (evento.keyCode) {
    case 37://código da seta (direcional)esquerda
      imagemAnterior();
      break;
    case 39://código do direcional direita
      proximaImagem();
      break;
  }
}
document.onkeydown = GerenciarTeclado;