function gerarTabela(){
    let times = [];
    let pontos = [];
    let saldoGols = [];
    let N = Number(prompt("Informe o Nº de times"));

        for(let i=0; i<N; i++){
            times.push(prompt(`Informe o nome do ${i + 1}º time: `)); 
            pontos.push(prompt(`A quantidade de pontos do ${i + 1}º time: `));
            saldoGols.push(prompt(`O saldo de gols do ${i + 1}º time: `));
    }

    let container = document.querySelector("#BRCONTAINER");
    let htmlTable= `

        <table>
            <tr><th>Posição</th><th>Time</th><th>Pontos</th><th>SG</th></tr>`;

        for(let i=0; i<N; i++){
            htmlTable +=` <tr><td>${i + 1}</td><td>${times[i]}</td><td>${pontos[i]}</td><td>${saldoGols[i]}</td><td>`;
        }

            htmlTable += `</table>`;
        container.innerHTML = htmlTable;

}

    let btn =document.querySelector("#BTNTBL");
    btn.addEventListener('click',gerarTabela);