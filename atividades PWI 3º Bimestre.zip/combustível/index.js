function calcular (){
    
    let escolha = document.getElementById('carros').value;
    let distancia = Number(document.getElementById('distancia').value);
    let conta;

    if (escolha == 'palio'){
        
        let conta = distancia/14;

        alert (conta);

    }


    else if (escolha == 'monza'){
        
        let conta = distancia/9;

        alert(conta);
        
    }

    else {
        
        let conta = distancia/10;

        alert(conta);
    }

        

}

let btn = document.getElementById('btncalcularconsumo');
btn.addEventListener('click',calcular);

