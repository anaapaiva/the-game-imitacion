let notas = 0;
let qtd = Number(prompt("Insira a quantidade de alunos: "));
let pesos = 0;

for(let i = 0; i < qtd; i++) {
    nota = Number(prompt("Insira a "+(i+1)+"º Nota: ")
        
    );
    let peso = (prompt("Insira o peso: "));
     notas+=(nota * peso);
     pesos+=peso;

}
let media = notas / pesos;
let elMedia = document.querySelector("#media");
elMedia.innerText = media;
