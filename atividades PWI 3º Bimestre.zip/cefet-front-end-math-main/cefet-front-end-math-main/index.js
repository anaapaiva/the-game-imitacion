const inputA = document.getElementById('coeficiente-a');
const inputB = document.getElementById('coeficiente-b');
const inputC = document.getElementById('coeficiente-c');

const botaoResolver = document.getElementById('resolverButton');

const inputDelta = document.getElementById('resultado-delta');
const inputX1 = document.getElementById('resultado-x1');
const inputX2 = document.getElementById('resultado-x2');
const inputQtdRaizes = document.getElementById('quantidade-raizes');
const inputParabolaDirecao = document.getElementById('direcao-parabola');
const inputVertice = document.getElementById('vertice');


function calculaParabola() {
    
    const a = parseFloat(inputA.value);
    const b = parseFloat(inputB.value);
    const c = parseFloat(inputC.value);

    
    if (a === 0) {
        alert("O coeficiente 'a' não pode ser zero!");
        return;
    }

    
    const delta = b * b - 4 * a * c;
    inputDelta.value = delta.toFixed(2); 

    
    let quantidadeRaizes;
    if (delta > 0) {
        quantidadeRaizes = 2; 
    } else if (delta === 0) {
        quantidadeRaizes = 1; 
    } else {
        quantidadeRaizes = 0; 
    }
    inputQtdRaizes.value = quantidadeRaizes;

   
    const direcaoParabola = a > 0 ? "Para cima" : "Para baixo";
    inputParabolaDirecao.value = direcaoParabola;

    
    const verticeX = -b / (2 * a);
    const verticeY = a * verticeX * verticeX + b * verticeX + c;
    inputVertice.value = ('${verticeX}, ${verticeY}');

    
    if (delta >= 0) {
        const raizDelta = Math.sqrt(delta);
        const x1 = (-b + raizDelta) / (2 * a);
        const x2 = (-b - raizDelta) / (2 * a);

        inputX1.value = x1;
        inputX2.value = x2;
    } else {
        
        inputX1.value = '';
        inputX2.value = '';
    }
}


botaoResolver.addEventListener('click', calculaParabola);